AquaGlow Calculator

A modern, responsive calculator with glowing neon effects and 3D button animations.  
Built using HTML, CSS, and JavaScript.

Features:
- Fully responsive design (works on all devices)
- Aqua neon glow and hover effects
- Smooth 3D press animations
- Supports +, −, ×, ÷ operations
- Includes clear (C) and decimal (.) buttons
- Easy-to-edit code structure

Usage:
- Download and unzip the folder.
- Open the file named 'AquaGlow-Calculator.html' in your browser.
- Start using the calculator instantly — no setup required.

License:
This project is free to use for educational and personal purposes.  
Redistribution, modification for commercial use, or resale without permission is strictly prohibited.

Author:
Created by ASWCode  
Visit: aswcode.com
