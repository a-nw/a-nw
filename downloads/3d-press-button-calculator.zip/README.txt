3D Press Button Calculator

A responsive and modern calculator made with HTML, CSS, and JavaScript.
It has smooth gradient colors and 3D press button effects for an interactive look.

Features:
- Fully responsive design (works on mobile and desktop)
- 3D press and hover animations on buttons
- Smooth gradient background
- Supports +, −, ×, ÷ operations
- Clear (C) and decimal (.) buttons
- Easy-to-edit HTML and CSS structure

Usage:
- Download and unzip the folder.
- Open the file named 3d-press-button-calculator.html in your browser.
- Start using the calculator instantly.

License:
This project is free to use for educational and personal purposes.
Redistribution, modification for commercial use, or resale without permission is strictly prohibited.

Author:
Created by ASWCode
Visit: aswcode.com